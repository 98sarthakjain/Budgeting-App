enum InvestmentType { mutualFund, stock, nps, gold, fd }
