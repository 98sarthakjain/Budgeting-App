import 'dart:convert';

import 'package:flutter/services.dart';

import 'package:budgeting_app/features/cards/data/card_repository.dart';
import 'package:budgeting_app/features/cards/domain/credit_card.dart';
import 'package:budgeting_app/features/cash/data/cash_account_repository.dart';
import 'package:budgeting_app/features/cash/domain/cash_account.dart';
import 'package:budgeting_app/features/savings/data/savings_account_repository.dart';
import 'package:budgeting_app/features/savings/domain/savings_account.dart';
import 'package:budgeting_app/features/transactions/data/transaction_repository.dart';
import 'package:budgeting_app/features/transactions/domain/transaction.dart';

/// Lightweight, dependency-free (no file picker) backup/export + import.
///
/// Goal: during early testing (crashes/resets), you can copy a JSON backup to
/// Notes/Drive, and later paste it back to restore.
///
/// This is intentionally simple and deterministic:
/// - Export produces a versioned JSON snapshot.
/// - Import defaults to **replace** (wipe existing data then re-create).
/// - IDs are not preserved for transactions (repository generates new IDs).
///   Accounts/cards preserve IDs if repositories accept them.
class LedgerPortabilityService {
  static const int currentSchemaVersion = 1;

  final SavingsAccountRepository savingsRepository;
  final CashAccountRepository cashRepository;
  final CardRepository cardRepository;
  final TransactionRepository transactionRepository;

  const LedgerPortabilityService({
    required this.savingsRepository,
    required this.cashRepository,
    required this.cardRepository,
    required this.transactionRepository,
  });

  Future<String> exportJson() async {
    final savings = await savingsRepository.getAllAccounts();
    final cash = await cashRepository.getAllAccounts();
    final cards = await cardRepository.getAllCards();
    final txns = await transactionRepository.query();

    txns.sort((a, b) => a.bookingDate.compareTo(b.bookingDate));

    final payload = <String, dynamic>{
      'schemaVersion': currentSchemaVersion,
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'savingsAccounts': savings.map(_savingsToJson).toList(growable: false),
      'cashAccounts': cash.map(_cashToJson).toList(growable: false),
      'creditCards': cards.map(_cardToJson).toList(growable: false),
      'transactions': txns.map(_txnToJson).toList(growable: false),
    };

    return const JsonEncoder.withIndent('  ').convert(payload);
  }

  Future<void> copyExportToClipboard() async {
    final json = await exportJson();
    await Clipboard.setData(ClipboardData(text: json));
  }

  Future<void> resetAllData() async {
    // Delete transactions first (so account balances don't matter).
    final allTxns = await transactionRepository.query();
    for (final t in allTxns) {
      await transactionRepository.deleteTransaction(t.id);
    }

    final cards = await cardRepository.getAllCards();
    for (final c in cards) {
      await cardRepository.deleteCard(c.id);
    }

    final cash = await cashRepository.getAllAccounts();
    for (final a in cash) {
      await cashRepository.deleteAccount(a.id);
    }

    final savings = await savingsRepository.getAllAccounts();
    for (final a in savings) {
      await savingsRepository.deleteAccount(a.id);
    }
  }

  /// Import a JSON backup.
  ///
  /// By default, this **replaces** all existing data.
  Future<void> importJson(String json, {bool replace = true}) async {
    final decoded = jsonDecode(json);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Invalid JSON backup: root is not an object');
    }

    final schemaVersion = decoded['schemaVersion'];
    if (schemaVersion != currentSchemaVersion) {
      throw FormatException(
        'Unsupported backup schemaVersion: $schemaVersion (expected $currentSchemaVersion)',
      );
    }

    if (replace) {
      await resetAllData();
    }

    final savings = _asList(decoded['savingsAccounts']);
    final cash = _asList(decoded['cashAccounts']);
    final cards = _asList(decoded['creditCards']);
    final txns = _asList(decoded['transactions']);

    for (final item in savings) {
      final a = _savingsFromJson(item);
      await savingsRepository.createAccount(a);
    }
    for (final item in cash) {
      final a = _cashFromJson(item);
      await cashRepository.createAccount(a);
    }
    for (final item in cards) {
      final c = _cardFromJson(item);
      await cardRepository.createCard(c);
    }

    // Transactions: create via repository helpers (new IDs) but preserve values.
    for (final item in txns) {
      final t = _txnFromJson(item);
      switch (t.type) {
        case TransactionType.income:
          await transactionRepository.createIncome(
            accountId: t.accountId,
            amount: t.amount,
            categoryId: t.categoryId,
            bookingDate: t.bookingDate,
            description: t.description,
            tags: t.tags,
          );
          break;
        case TransactionType.expense:
          await transactionRepository.createExpense(
            accountId: t.accountId,
            amount: t.amount,
            categoryId: t.categoryId,
            bookingDate: t.bookingDate,
            description: t.description,
            tags: t.tags,
          );
          break;
        case TransactionType.openingBalance:
          await transactionRepository.createOpeningBalance(
            accountId: t.accountId,
            amount: t.amount,
            bookingDate: t.bookingDate,
            description: t.description,
            tags: t.tags,
          );
          break;
        case TransactionType.transferIn:
        case TransactionType.transferOut:
          // We export both sides, but on import we only need to create a single
          // transfer. We'll create it once when we see the transferOut side.
          if (t.type == TransactionType.transferOut && t.transferToAccountId != null) {
            await transactionRepository.createTransfer(
              fromAccountId: t.accountId,
              toAccountId: t.transferToAccountId!,
              amount: t.amount,
              bookingDate: t.bookingDate,
              description: t.description,
              tags: t.tags,
            );
          }
          break;
        case TransactionType.adjustment:
          // Keep it as an income/expense depending on sign.
          if (t.amount >= 0) {
            await transactionRepository.createIncome(
              accountId: t.accountId,
              amount: t.amount,
              categoryId: t.categoryId,
              bookingDate: t.bookingDate,
              description: t.description,
              tags: t.tags,
            );
          } else {
            await transactionRepository.createExpense(
              accountId: t.accountId,
              amount: -t.amount,
              categoryId: t.categoryId,
              bookingDate: t.bookingDate,
              description: t.description,
              tags: t.tags,
            );
          }
          break;
      }
    }
  }

  /// A simple CSV template you can paste into a Google Sheet.
  ///
  /// Import supports record types:
  /// - SAVINGS, CASH, CARD, TXN
  ///
  /// Notes:
  /// - For CARD openingBalance, use a negative number to represent amount due.
  /// - TXN.kind: income | expense | opening | transfer
  /// - TXN uses accountKey/fromKey/toKey to reference accounts by key.
  static String csvTemplate() {
    return [
      'recordType,key,name,bank,numberLast4,openingBalance,date,kind,amount,accountKey,fromKey,toKey,category,description,tags',
      // Accounts
      'SAVINGS,SAV-EMERGENCY,Emergency Fund,HDFC,1234,50000,2026-01-01,,,,,,,,',
      'CASH,CASH-HAND,Cash in Hand,,,	2000,2026-01-01,,,,,,,,',
      'CARD,CARD-AMAZON,Amazon Pay ICICI,ICICI,9876,-12000,2026-01-01,,,,,,,,',
      // Transactions
      'TXN,,,,,,2026-01-05,income,8000,SAV-EMERGENCY,,,Salary,January Salary,"salary,jan"',
      'TXN,,,,,,2026-01-06,expense,500,SAV-EMERGENCY,,,Food,Lunch,"food"',
      'TXN,,,,,,2026-01-07,transfer,1500,,SAV-EMERGENCY,CASH-HAND,,ATM Withdrawal,"transfer"',
      'TXN,,,,,,2026-01-08,transfer,2000,,SAV-EMERGENCY,CARD-AMAZON,,Card Payment,"card,payment"',
    ].join('\n');
  }

  /// Import CSV that matches [csvTemplate]. Defaults to replace.
  Future<void> importCsv(String csv, {bool replace = true}) async {
    final rows = const LineSplitter().convert(csv.trim());
    if (rows.isEmpty) return;

    // Basic CSV split (good enough for our controlled template).
    // If the user adds commas inside values, they should wrap the cell in quotes.
    List<String> splitRow(String row) {
      final out = <String>[];
      final buf = StringBuffer();
      bool inQuotes = false;
      for (int i = 0; i < row.length; i++) {
        final ch = row[i];
        if (ch == '"') {
          inQuotes = !inQuotes;
          continue;
        }
        if (ch == ',' && !inQuotes) {
          out.add(buf.toString());
          buf.clear();
          continue;
        }
        buf.write(ch);
      }
      out.add(buf.toString());
      return out.map((e) => e.trim()).toList(growable: false);
    }

    final header = splitRow(rows.first);
    final idx = <String, int>{
      for (int i = 0; i < header.length; i++) header[i]: i,
    };

    String cell(List<String> cols, String name) {
      final i = idx[name];
      if (i == null || i >= cols.length) return '';
      return cols[i];
    }

    if (replace) {
      await resetAllData();
    }

    // Map account keys to IDs so TXNs can reference them.
    final keyToId = <String, String>{};

    // First pass: create accounts/cards.
    for (final row in rows.skip(1)) {
      if (row.trim().isEmpty) continue;
      final cols = splitRow(row);
      final recordType = cell(cols, 'recordType').toUpperCase();
      final key = cell(cols, 'key');
      final name = cell(cols, 'name');
      final bank = cell(cols, 'bank');
      final last4 = cell(cols, 'numberLast4');
      final openingStr = cell(cols, 'openingBalance');
      final dateStr = cell(cols, 'date');
      final opening = double.tryParse(openingStr.replaceAll('\t', '').trim()) ?? 0.0;
      final date = DateTime.tryParse(dateStr) ?? DateTime.now();

      if (recordType == 'SAVINGS') {
        final a = SavingsAccount(
          id: _stableIdFromKey('sav', key),
          bankName: bank,
          accountName: name,
          maskedAccountNumber: last4.isEmpty ? null : last4,
        );
        await savingsRepository.createAccount(a);
        keyToId[key] = a.id;
        if (opening != 0) {
          await transactionRepository.createOpeningBalance(
            accountId: a.id,
            amount: opening,
            bookingDate: date,
            description: 'Opening balance',
            tags: const ['import'],
          );
        }
      } else if (recordType == 'CASH') {
        final a = CashAccount(
          id: _stableIdFromKey('cash', key),
          accountName: name,
        );
        await cashRepository.createAccount(a);
        keyToId[key] = a.id;
        if (opening != 0) {
          await transactionRepository.createOpeningBalance(
            accountId: a.id,
            amount: opening,
            bookingDate: date,
            description: 'Opening balance',
            tags: const ['import'],
          );
        }
      } else if (recordType == 'CARD') {
        final c = CreditCard(
          id: _stableIdFromKey('card', key),
          bankName: bank,
          cardName: name,
          last4: last4.isEmpty ? null : last4,
        );
        await cardRepository.createCard(c);
        keyToId[key] = c.id;
        if (opening != 0) {
          await transactionRepository.createOpeningBalance(
            accountId: c.id,
            amount: opening,
            bookingDate: date,
            description: 'Opening balance (card due)',
            tags: const ['import'],
          );
        }
      }
    }

    // Second pass: transactions.
    for (final row in rows.skip(1)) {
      if (row.trim().isEmpty) continue;
      final cols = splitRow(row);
      final recordType = cell(cols, 'recordType').toUpperCase();
      if (recordType != 'TXN') continue;

      final kind = cell(cols, 'kind').toLowerCase();
      final amount = double.tryParse(cell(cols, 'amount')) ?? 0.0;
      final date = DateTime.tryParse(cell(cols, 'date')) ?? DateTime.now();
      final category = cell(cols, 'category');
      final description = cell(cols, 'description');
      final tagsStr = cell(cols, 'tags');
      final tags = tagsStr.isEmpty
          ? const <String>[]
          : tagsStr
              .split(RegExp(r'[;|,]'))
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .toList(growable: false);

      if (kind == 'income' || kind == 'expense' || kind == 'opening') {
        final accountKey = cell(cols, 'accountKey');
        final accountId = keyToId[accountKey];
        if (accountId == null) continue;

        if (kind == 'income') {
          await transactionRepository.createIncome(
            accountId: accountId,
            amount: amount,
            categoryId: category,
            bookingDate: date,
            description: description,
            tags: tags,
          );
        } else if (kind == 'expense') {
          await transactionRepository.createExpense(
            accountId: accountId,
            amount: amount,
            categoryId: category,
            bookingDate: date,
            description: description,
            tags: tags,
          );
        } else {
          await transactionRepository.createOpeningBalance(
            accountId: accountId,
            amount: amount,
            bookingDate: date,
            description: description.isEmpty ? 'Opening balance' : description,
            tags: tags,
          );
        }
      } else if (kind == 'transfer') {
        final fromKey = cell(cols, 'fromKey');
        final toKey = cell(cols, 'toKey');
        final fromId = keyToId[fromKey];
        final toId = keyToId[toKey];
        if (fromId == null || toId == null) continue;
        await transactionRepository.createTransfer(
          fromAccountId: fromId,
          toAccountId: toId,
          amount: amount,
          bookingDate: date,
          description: description,
          tags: tags,
        );
      }
    }
  }
}

List<dynamic> _asList(dynamic v) {
  if (v is List) return v;
  return const <dynamic>[];
}

String _stableIdFromKey(String prefix, String key) {
  final safe = key.trim().replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
  return '${prefix}_$safe';
}

Map<String, dynamic> _savingsToJson(SavingsAccount a) => {
      'id': a.id,
      'bankName': a.bankName,
      'accountName': a.accountName,
      'maskedAccountNumber': a.maskedAccountNumber,
    };

SavingsAccount _savingsFromJson(dynamic v) {
  final m = (v as Map).cast<String, dynamic>();
  return SavingsAccount(
    id: (m['id'] ?? '').toString(),
    bankName: (m['bankName'] ?? '').toString(),
    accountName: (m['accountName'] ?? '').toString(),
    maskedAccountNumber: m['maskedAccountNumber']?.toString(),
  );
}

Map<String, dynamic> _cashToJson(CashAccount a) => {
      'id': a.id,
      'accountName': a.accountName,
    };

CashAccount _cashFromJson(dynamic v) {
  final m = (v as Map).cast<String, dynamic>();
  return CashAccount(
    id: (m['id'] ?? '').toString(),
    accountName: (m['accountName'] ?? '').toString(),
  );
}

Map<String, dynamic> _cardToJson(CreditCard c) => {
      'id': c.id,
      'bankName': c.bankName,
      'cardName': c.cardName,
      'last4': c.last4,
    };

CreditCard _cardFromJson(dynamic v) {
  final m = (v as Map).cast<String, dynamic>();
  return CreditCard(
    id: (m['id'] ?? '').toString(),
    bankName: (m['bankName'] ?? '').toString(),
    cardName: (m['cardName'] ?? '').toString(),
    last4: m['last4']?.toString(),
  );
}

Map<String, dynamic> _txnToJson(Transaction t) => {
      'id': t.id,
      'accountId': t.accountId,
      'type': t.type.name,
      'amount': t.amount,
      'bookingDate': t.bookingDate.toIso8601String(),
      'categoryId': t.categoryId,
      'description': t.description,
      'tags': t.tags,
      'transferToAccountId': t.transferToAccountId,
    };

Transaction _txnFromJson(dynamic v) {
  final m = (v as Map).cast<String, dynamic>();
  final typeName = (m['type'] ?? 'expense').toString();
  final type = TransactionType.values.firstWhere(
    (e) => e.name == typeName,
    orElse: () => TransactionType.expense,
  );
  return Transaction(
    id: (m['id'] ?? '').toString(),
    accountId: (m['accountId'] ?? '').toString(),
    type: type,
    amount: (m['amount'] is num) ? (m['amount'] as num).toDouble() : 0.0,
    bookingDate: DateTime.tryParse((m['bookingDate'] ?? '').toString()) ?? DateTime.now(),
    categoryId: m['categoryId']?.toString(),
    description: m['description']?.toString(),
    tags: (m['tags'] is List)
        ? (m['tags'] as List).map((e) => e.toString()).toList(growable: false)
        : const <String>[],
    transferToAccountId: m['transferToAccountId']?.toString(),
  );
}
