import 'package:flutter/material.dart';

import 'package:budgeting_app/core/design/spacing.dart';
import 'package:budgeting_app/core/widgets/app_card.dart';
import 'package:budgeting_app/core/services/app_currency_service.dart';

import 'package:budgeting_app/features/transactions/data/transaction_repository.dart';
import 'package:budgeting_app/features/transactions/domain/transaction.dart';

import 'package:budgeting_app/features/savings/data/savings_account_repository.dart';
import 'package:budgeting_app/features/savings/domain/savings_account.dart';

import 'package:budgeting_app/features/cash/data/cash_account_repository.dart';
import 'package:budgeting_app/features/cash/domain/cash_account.dart';

import 'package:budgeting_app/features/cards/data/card_repository.dart';
import 'package:budgeting_app/features/cards/domain/credit_card.dart';

/// v1: single-entry manual transaction input.
///
/// **Ledger truth:** this screen writes into [TransactionRepository].
/// Balances are derived by summing transactions (see global_financial_rules.md).
class AddTransactionScreen extends StatefulWidget {
  final TransactionRepository transactionRepository;
  final SavingsAccountRepository savingsRepository;
  final CashAccountRepository cashRepository;
  final CardRepository cardRepository;

  const AddTransactionScreen({
    super.key,
    required this.transactionRepository,
    required this.savingsRepository,
    required this.cashRepository,
    required this.cardRepository,
  });

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

enum _TxnKind { expense, income }

enum _ExpenseMode { savings, cash, creditCard }

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();

  _TxnKind _kind = _TxnKind.expense;
  _ExpenseMode _expenseMode = _ExpenseMode.savings;

  SavingsAccount? _selectedSavings;
  CashAccount? _selectedCash;
  CreditCard? _selectedCard;

  final _amountController = TextEditingController();
  final _descController = TextEditingController();

  bool _isSaving = false;

  @override
  void dispose() {
    _amountController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Future<void> _save(
    List<SavingsAccount> savings,
    List<CashAccount> cash,
    List<CreditCard> cards,
  ) async {
    if (_isSaving) return;
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);
    try {
      final amount =
          double.tryParse(_amountController.text.replaceAll(',', '').trim()) ??
              0;
      final desc = _descController.text.trim();
      final now = DateTime.now();

      // Ensure we have selections.
      _selectedSavings ??= savings.isNotEmpty ? savings.first : null;
      _selectedCash ??= cash.isNotEmpty ? cash.first : null;
      _selectedCard ??= cards.isNotEmpty ? cards.first : null;

      if (_kind == _TxnKind.income) {
        final targetId = _selectedSavings?.id ?? _selectedCash?.id;
        if (targetId == null) {
          _showSnack('Create a savings/cash account first.');
          return;
        }

        await widget.transactionRepository.createIncome(
          accountId: targetId,
          amount: amount,
          bookingDate: now,
          description: desc.isEmpty ? 'Income' : desc,
          tags: const [],
        );
      } else {
        // Expense
        String? accountId;
        switch (_expenseMode) {
          case _ExpenseMode.savings:
            accountId = _selectedSavings?.id;
            break;
          case _ExpenseMode.cash:
            accountId = _selectedCash?.id;
            break;
          case _ExpenseMode.creditCard:
            // Credit cards are liabilities.
            // We still write this as an EXPENSE transaction so analytics work.
            // Card "amount due" is derived as: due = -ledgerBalance.
            accountId = _selectedCard?.id;
            break;
        }

        if (accountId == null) {
          _showSnack('Select an account first.');
          return;
        }

        await widget.transactionRepository.createExpense(
          accountId: accountId,
          amount: amount,
          bookingDate: now,
          categoryId: null,
          description: desc.isEmpty ? 'Expense' : desc,
          tags: const [],
        );
      }

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final currency = AppCurrencyService.instance;

    return Scaffold(
      appBar: AppBar(title: const Text('Add transaction')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: StreamBuilder<List<SavingsAccount>>(
            stream: widget.savingsRepository.watchAllAccounts(),
            initialData: const [],
            builder: (context, savingsSnap) {
              return StreamBuilder<List<CashAccount>>(
                stream: widget.cashRepository.watchAllAccounts(),
                initialData: const [],
                builder: (context, cashSnap) {
                  return StreamBuilder<List<CreditCard>>(
                    stream: widget.cardRepository.watchAllCards(),
                    initialData: const [],
                    builder: (context, cardSnap) {
                      final savings = savingsSnap.data ?? const [];
                      final cash = cashSnap.data ?? const [];
                      final cards = cardSnap.data ?? const [];

                      _selectedSavings ??=
                          savings.isNotEmpty ? savings.first : null;
                      _selectedCash ??= cash.isNotEmpty ? cash.first : null;
                      _selectedCard ??= cards.isNotEmpty ? cards.first : null;

                      return Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            // Kind toggle
                            AppCard(
                              child: Padding(
                                padding: const EdgeInsets.all(AppSpacing.md),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: ChoiceChip(
                                        label: const Text('Expense'),
                                        selected: _kind == _TxnKind.expense,
                                        onSelected: (_) {
                                          setState(() {
                                            _kind = _TxnKind.expense;
                                          });
                                        },
                                      ),
                                    ),
                                    const SizedBox(width: AppSpacing.sm),
                                    Expanded(
                                      child: ChoiceChip(
                                        label: const Text('Income'),
                                        selected: _kind == _TxnKind.income,
                                        onSelected: (_) {
                                          setState(() {
                                            _kind = _TxnKind.income;
                                          });
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: AppSpacing.lg),

                            // Amount
                            TextFormField(
                              controller: _amountController,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                labelText: 'Amount',
                                prefixText: '${currency.baseSymbol} ',
                              ),
                              validator: (v) {
                                final n = double.tryParse(
                                  (v ?? '').replaceAll(',', '').trim(),
                                );
                                if (n == null || n <= 0) {
                                  return 'Enter a valid amount';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: AppSpacing.md),

                            // Description
                            TextFormField(
                              controller: _descController,
                              decoration: const InputDecoration(
                                labelText: 'Description (optional)',
                              ),
                            ),
                            const SizedBox(height: AppSpacing.lg),

                            // Payment / target account
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                _kind == _TxnKind.income
                                    ? 'Deposit into'
                                    : 'Paid via',
                                style: textTheme.titleMedium,
                              ),
                            ),
                            const SizedBox(height: AppSpacing.sm),

                            if (_kind == _TxnKind.income)
                              _IncomeTargetPicker(
                                savings: savings,
                                cash: cash,
                                selectedSavings: _selectedSavings,
                                selectedCash: _selectedCash,
                                onPickSavings: (a) {
                                  setState(() {
                                    _selectedSavings = a;
                                    _selectedCash = null;
                                  });
                                },
                                onPickCash: (a) {
                                  setState(() {
                                    _selectedCash = a;
                                    _selectedSavings = null;
                                  });
                                },
                              )
                            else
                              _ExpenseSourcePicker(
                                savings: savings,
                                cash: cash,
                                cards: cards,
                                mode: _expenseMode,
                                selectedSavings: _selectedSavings,
                                selectedCash: _selectedCash,
                                selectedCard: _selectedCard,
                                onModeChange: (m) {
                                  setState(() => _expenseMode = m);
                                },
                                onPickSavings: (a) {
                                  setState(() => _selectedSavings = a);
                                },
                                onPickCash: (a) {
                                  setState(() => _selectedCash = a);
                                },
                                onPickCard: (c) {
                                  setState(() => _selectedCard = c);
                                },
                              ),

                            const Spacer(),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton(
                                onPressed: _isSaving
                                    ? null
                                    : () => _save(savings, cash, cards),
                                child: _isSaving
                                    ? const SizedBox(
                                        height: 18,
                                        width: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Text('Save'),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}

class _IncomeTargetPicker extends StatelessWidget {
  final List<SavingsAccount> savings;
  final List<CashAccount> cash;
  final SavingsAccount? selectedSavings;
  final CashAccount? selectedCash;
  final ValueChanged<SavingsAccount> onPickSavings;
  final ValueChanged<CashAccount> onPickCash;

  const _IncomeTargetPicker({
    required this.savings,
    required this.cash,
    required this.selectedSavings,
    required this.selectedCash,
    required this.onPickSavings,
    required this.onPickCash,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Savings accounts', style: textTheme.bodyMedium),
            const SizedBox(height: AppSpacing.xs),
            if (savings.isEmpty)
              const Text('No savings accounts yet')
            else
              DropdownButtonFormField<SavingsAccount>(
                value: selectedSavings ?? savings.first,
                items: [
                  for (final a in savings)
                    DropdownMenuItem(
                      value: a,
                      child: Text('${a.accountNickname} • ${a.bankName}'),
                    ),
                ],
                onChanged: (v) {
                  if (v != null) onPickSavings(v);
                },
              ),
            const SizedBox(height: AppSpacing.md),
            Text('Cash wallets', style: textTheme.bodyMedium),
            const SizedBox(height: AppSpacing.xs),
            if (cash.isEmpty)
              const Text('No cash wallets yet')
            else
              DropdownButtonFormField<CashAccount>(
                value: selectedCash ?? cash.first,
                items: [
                  for (final a in cash)
                    DropdownMenuItem(value: a, child: Text(a.name)),
                ],
                onChanged: (v) {
                  if (v != null) onPickCash(v);
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _ExpenseSourcePicker extends StatelessWidget {
  final List<SavingsAccount> savings;
  final List<CashAccount> cash;
  final List<CreditCard> cards;

  final _ExpenseMode mode;
  final SavingsAccount? selectedSavings;
  final CashAccount? selectedCash;
  final CreditCard? selectedCard;

  final ValueChanged<_ExpenseMode> onModeChange;
  final ValueChanged<SavingsAccount> onPickSavings;
  final ValueChanged<CashAccount> onPickCash;
  final ValueChanged<CreditCard> onPickCard;

  const _ExpenseSourcePicker({
    required this.savings,
    required this.cash,
    required this.cards,
    required this.mode,
    required this.selectedSavings,
    required this.selectedCash,
    required this.selectedCard,
    required this.onModeChange,
    required this.onPickSavings,
    required this.onPickCash,
    required this.onPickCard,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Payment mode', style: textTheme.bodyMedium),
            const SizedBox(height: AppSpacing.xs),
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: [
                ChoiceChip(
                  label: const Text('Savings'),
                  selected: mode == _ExpenseMode.savings,
                  onSelected: (_) => onModeChange(_ExpenseMode.savings),
                ),
                ChoiceChip(
                  label: const Text('Cash'),
                  selected: mode == _ExpenseMode.cash,
                  onSelected: (_) => onModeChange(_ExpenseMode.cash),
                ),
                ChoiceChip(
                  label: const Text('Credit card'),
                  selected: mode == _ExpenseMode.creditCard,
                  onSelected: (_) => onModeChange(_ExpenseMode.creditCard),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),

            if (mode == _ExpenseMode.savings)
              if (savings.isEmpty)
                const Text('No savings accounts yet')
              else
                DropdownButtonFormField<SavingsAccount>(
                  value: selectedSavings ?? savings.first,
                  items: [
                    for (final a in savings)
                      DropdownMenuItem(
                        value: a,
                        child: Text('${a.accountNickname} • ${a.bankName}'),
                      ),
                  ],
                  onChanged: (v) {
                    if (v != null) onPickSavings(v);
                  },
                )
            else if (mode == _ExpenseMode.cash)
              if (cash.isEmpty)
                const Text('No cash wallets yet')
              else
                DropdownButtonFormField<CashAccount>(
                  value: selectedCash ?? cash.first,
                  items: [
                    for (final a in cash)
                      DropdownMenuItem(value: a, child: Text(a.name)),
                  ],
                  onChanged: (v) {
                    if (v != null) onPickCash(v);
                  },
                )
            else
              if (cards.isEmpty)
                const Text('No credit cards yet')
              else
                DropdownButtonFormField<CreditCard>(
                  value: selectedCard ?? cards.first,
                  items: [
                    for (final c in cards)
                      DropdownMenuItem(
                        value: c,
                        child: Text(c.nickname),
                      ),
                  ],
                  onChanged: (v) {
                    if (v != null) onPickCard(v);
                  },
                ),
          ],
        ),
      ),
    );
  }
}
